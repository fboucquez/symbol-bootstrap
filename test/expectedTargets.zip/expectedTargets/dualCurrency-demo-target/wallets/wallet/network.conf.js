var networkTypeConfig = {
  "explorerUrl": "",
  "faucetUrl": "http://localhost:100",
  "defaultNetworkType": 152,
  "defaultNodeUrl": "http://localhost:3000",
  "networkConfigurationDefaults": {
    "maxMosaicDivisibility": 6,
    "namespaceGracePeriodDuration": 2592000,
    "lockedFundsPerAggregate": "10000000",
    "maxCosignatoriesPerAccount": 25,
    "blockGenerationTargetTime": 15,
    "maxNamespaceDepth": 3,
    "maxMosaicDuration": 315360000,
    "minNamespaceDuration": 60,
    "maxNamespaceDuration": 31536000,
    "maxTransactionsPerAggregate": 100,
    "maxCosignedAccountsPerAccount": 25,
    "maxMessageSize": 1024,
    "maxMosaicAtomicUnits":  9000000000000000,
    "currencyMosaicId": "216D32373BC07F6B",
    "harvestingMosaicId": "051C52C8BDE85011",
    "defaultDynamicFeeMultiplier": 1000,
    "epochAdjustment": 1573430400,
    "totalChainImportance": 15000000,
    "generationHash": "0000000000000000000000000000000000000000000000000000000000000CCC"
  },
  "nodes": [
    {"friendlyName": "localhost", "roles": 2, "url": "http://localhost:3000"},
  ]
}
var networkConfig = { 152 : networkTypeConfig }
window.networkConfig = networkConfig
console.log('networkConfig loaded!', networkConfig)




