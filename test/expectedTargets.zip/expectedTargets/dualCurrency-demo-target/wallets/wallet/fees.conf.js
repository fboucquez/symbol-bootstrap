var feesConfig = {
  median: 10,
  free: 0,
  slow: 5,
  slowest: 1,
  fast: 20,
}
window.feesConfig = feesConfig
console.log('feesConfig loaded!', feesConfig)
